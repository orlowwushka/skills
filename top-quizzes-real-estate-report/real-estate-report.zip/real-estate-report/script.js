const progress = document.getElementById("progress");
const tocLinks = document.querySelectorAll(".toc-link");
const sections = [...document.querySelectorAll(".hero, .chapter, .guide, .outro, .method")];

function onScroll() {
  const scrollTop = document.documentElement.scrollTop;
  const scrollHeight =
    document.documentElement.scrollHeight - document.documentElement.clientHeight;
  const pct = scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0;
  progress.style.width = `${pct}%`;

  let current = sections[0]?.id || "hero";
  for (const section of sections) {
    const top = section.offsetTop - 120;
    if (scrollTop >= top) current = section.id;
  }

  tocLinks.forEach((link) => {
    const href = link.getAttribute("href")?.slice(1);
    link.classList.toggle("is-active", href === current);
  });
}

window.addEventListener("scroll", onScroll, { passive: true });
onScroll();
